import {
  useGetStatsSummary,
  useGetEquityCurve,
  useGetWeeklyPnl,
  useListTrades,
  useGetCalendarHeatmap,
} from "@workspace/api-client-react";
import { formatCurrency } from "@/lib/utils";
import { motion } from "framer-motion";
import {
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Percent,
  Layers,
  BarChart2,
  Activity,
  Target,
  Flame,
  ChevronRight,
} from "lucide-react";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Bar,
  BarChart as RechartsBarChart,
  Cell,
  PieChart,
  Pie,
  Legend,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { useMemo } from "react";
import { Link } from "wouter";

const BROKER_MAP: Record<string, string> = {
  NAS100: "IC Markets", US30: "IC Markets", US500: "IC Markets",
  XAUUSD: "Pepperstone", EURUSD: "Pepperstone",
  BTCUSD: "Deriv", ETHUSD: "Deriv", SOLUSD: "Deriv",
  DOGEUSD: "Deriv", PEPEUSD: "Deriv", "Crude Oil": "OANDA",
};

const GREEN = "hsl(142 70% 48%)";
const RED = "hsl(0 72% 55%)";
const PURPLE = "hsl(265 85% 65%)";
const MUTED_CLR = "hsl(220 10% 35%)";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.38, ease: "easeOut" } },
};

const tooltipStyle = {
  backgroundColor: "hsl(225 28% 9%)",
  borderColor: "rgba(255,255,255,0.08)",
  borderRadius: "10px",
  boxShadow: "0 12px 40px rgba(0,0,0,0.5)",
  fontSize: "12px",
  padding: "8px 12px",
};

function StatCard({
  label, value, sub, icon: Icon, positive, accent, bar, trend,
}: {
  label: string;
  value: string;
  sub?: React.ReactNode;
  icon: React.ElementType;
  positive?: boolean;
  accent?: boolean;
  bar?: number;
  trend?: string;
}) {
  return (
    <motion.div variants={item} className="h-full">
      <div className="glass-card stat-card-glow h-full relative overflow-hidden group hover:border-white/[0.12] transition-all duration-300 p-5">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/[0.04] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
        <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-primary/[0.04] group-hover:bg-primary/[0.08] transition-colors duration-500 pointer-events-none" />

        <div className="relative flex items-start justify-between mb-4">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">{label}</p>
          <div className="p-1.5 rounded-lg bg-white/[0.04] border border-white/[0.06] group-hover:bg-primary/10 group-hover:border-primary/20 transition-all duration-300">
            <Icon className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
          </div>
        </div>

        <div className={`relative text-[26px] font-black tracking-tight mb-1.5 leading-none ${
          accent ? "text-foreground" :
          positive === true ? "text-emerald-400" :
          positive === false ? "text-red-400" :
          "text-foreground"
        }`}>
          {value}
        </div>

        {bar !== undefined && (
          <div className="mt-2.5 mb-2 h-1 w-full bg-white/[0.06] rounded-full overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: bar >= 55 ? "linear-gradient(90deg, hsl(142 70% 40%), hsl(142 70% 55%))" : bar >= 40 ? `linear-gradient(90deg, ${PURPLE}, hsl(265 85% 75%))` : "linear-gradient(90deg, hsl(0 72% 45%), hsl(0 72% 60%))" }}
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(bar, 100)}%` }}
              transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
            />
          </div>
        )}

        {sub && <p className="text-[11px] text-muted-foreground">{sub}</p>}
        {trend && <p className="text-[11px] text-emerald-400 font-medium mt-0.5">{trend}</p>}
      </div>
    </motion.div>
  );
}

function CalendarHeatmap({ data, year, month }: {
  data: Array<{ date: string; pnl: number; trades: number }>;
  year: number;
  month: number;
}) {
  const dayMap = useMemo(() => {
    const m: Record<string, { pnl: number; trades: number }> = {};
    data.forEach((d) => { m[d.date] = { pnl: d.pnl, trades: d.trades }; });
    return m;
  }, [data]);

  const firstDay = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();
  const maxAbs = useMemo(() => Math.max(...data.map((d) => Math.abs(d.pnl)), 1), [data]);

  const getCellStyle = (dateStr: string): React.CSSProperties => {
    const d = dayMap[dateStr];
    if (!d || d.trades === 0) return {};
    const intensity = Math.min(Math.abs(d.pnl) / maxAbs, 1);
    if (d.pnl > 0) return { backgroundColor: `rgba(52,211,153,${0.12 + intensity * 0.55})`, borderColor: `rgba(52,211,153,${0.2 + intensity * 0.3})` };
    if (d.pnl < 0) return { backgroundColor: `rgba(248,113,113,${0.12 + intensity * 0.55})`, borderColor: `rgba(248,113,113,${0.2 + intensity * 0.3})` };
    return { backgroundColor: "rgba(255,255,255,0.05)", borderColor: "rgba(255,255,255,0.1)" };
  };

  const monthName = new Date(year, month - 1).toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const days: React.ReactNode[] = [];
  for (let i = 0; i < firstDay; i++) {
    days.push(<div key={`empty-${i}`} />);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const entry = dayMap[dateStr];
    days.push(
      <div
        key={dateStr}
        className="relative rounded-lg aspect-square flex flex-col items-center justify-center cursor-default transition-all duration-200 hover:scale-[1.1] hover:z-10 group/cell border border-transparent"
        style={getCellStyle(dateStr)}
      >
        <span className="text-[10px] font-semibold leading-none text-foreground/60">{d}</span>
        {entry && entry.trades > 0 && (
          <span className={`text-[8px] font-bold leading-none mt-0.5 ${entry.pnl > 0 ? "text-emerald-400" : "text-red-400"}`}>
            {entry.pnl > 0 ? "+" : ""}{Math.abs(entry.pnl) >= 100 ? `$${Math.round(Math.abs(entry.pnl))}` : `$${Math.abs(entry.pnl).toFixed(0)}`}
          </span>
        )}
        {entry && entry.trades > 0 && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-20 hidden group-hover/cell:block pointer-events-none">
            <div className="glass-card px-2.5 py-1.5 text-[11px] whitespace-nowrap shadow-xl border-white/10">
              <p className={`font-bold ${entry.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>{formatCurrency(entry.pnl)}</p>
              <p className="text-muted-foreground">{entry.trades} trade{entry.trades !== 1 ? "s" : ""}</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <p className="text-xs font-semibold text-muted-foreground mb-3">{monthName}</p>
      <div className="grid grid-cols-7 gap-1 mb-1.5">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((d) => (
          <div key={d} className="text-center text-[10px] font-semibold text-muted-foreground/60 py-0.5">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">{days}</div>
    </div>
  );
}

function CustomEquityTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={tooltipStyle} className="border border-white/[0.08]">
      <p className="text-muted-foreground text-[11px] mb-1">{label ? new Date(label).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : ""}</p>
      <p className="font-bold text-sm text-white">{formatCurrency(payload[0].value)}</p>
    </div>
  );
}

function CustomPnlTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number }>; label?: string }) {
  if (!active || !payload?.length) return null;
  const val = payload[0].value;
  return (
    <div style={tooltipStyle} className="border border-white/[0.08]">
      <p className="text-muted-foreground text-[11px] mb-1">Week of {label}</p>
      <p className={`font-bold text-sm ${val >= 0 ? "text-emerald-400" : "text-red-400"}`}>{val >= 0 ? "+" : ""}{formatCurrency(val)}</p>
    </div>
  );
}

export default function Dashboard() {
  const { data: stats } = useGetStatsSummary();
  const { data: equity } = useGetEquityCurve();
  const { data: weeklyPnl } = useGetWeeklyPnl();
  const { data: recentTrades } = useListTrades({ limit: 10 });

  const now = new Date();
  const { data: calData } = useGetCalendarHeatmap({ year: now.getFullYear(), month: now.getMonth() + 1 });

  const winLossData = useMemo(() => {
    if (!stats) return [];
    return [
      { name: "Win", value: stats.winCount, color: GREEN },
      { name: "Loss", value: stats.lossCount, color: RED },
      { name: "BE", value: stats.breakevenCount, color: MUTED_CLR },
    ].filter((d) => d.value > 0);
  }, [stats]);

  if (!stats || !equity || !weeklyPnl || !recentTrades) {
    return (
      <div className="space-y-5 pb-12">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-28 rounded-2xl shimmer-loading" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 h-64 rounded-2xl shimmer-loading" />
          <div className="h-64 rounded-2xl shimmer-loading" />
        </div>
      </div>
    );
  }

  const weeklyLabels = weeklyPnl.map((w) => {
    const d = new Date(w.week);
    return { ...w, label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) };
  });

  return (
    <motion.div className="space-y-4 pb-12" variants={container} initial="hidden" animate="show">
      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <StatCard
          label="Net PNL"
          value={formatCurrency(stats.netPnl)}
          icon={stats.netPnl >= 0 ? ArrowUpRight : ArrowDownRight}
          positive={stats.netPnl > 0 ? true : stats.netPnl < 0 ? false : undefined}
          sub={<span className="flex items-center gap-1"><span className={stats.netPnl >= 0 ? "text-emerald-400" : "text-red-400"}>{stats.netPnl >= 0 ? "▲" : "▼"}</span>All time</span>}
        />
        <StatCard
          label="Win Rate"
          value={`${stats.winRate.toFixed(1)}%`}
          icon={Percent}
          accent
          bar={stats.winRate}
          sub={`${stats.winCount}W · ${stats.lossCount}L · ${stats.breakevenCount}BE`}
        />
        <StatCard
          label="Profit Factor"
          value={stats.profitFactor.toFixed(2)}
          icon={TrendingUp}
          accent
          positive={stats.profitFactor >= 1.5 ? true : stats.profitFactor < 1 ? false : undefined}
          sub="Gross Win / Gross Loss"
        />
        <StatCard
          label="Avg RR"
          value={`${stats.averageRR.toFixed(2)}R`}
          icon={Target}
          accent
          positive={stats.averageRR >= 2 ? true : stats.averageRR < 1 ? false : undefined}
          sub="Reward / Risk ratio"
        />
        <StatCard
          label="Total Trades"
          value={`${stats.totalTrades}`}
          icon={Layers}
          accent
          sub={<span><span className="text-emerald-400 font-semibold">{stats.winCount}W</span>{" · "}<span className="text-red-400 font-semibold">{stats.lossCount}L</span>{stats.breakevenCount > 0 && <span className="text-muted-foreground"> · {stats.breakevenCount}BE</span>}</span>}
        />
      </div>

      {/* ── Equity Curve + Weekly PNL ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div variants={item} className="lg:col-span-2">
          <div className="glass-card h-full">
            <div className="p-5 pb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-primary/15 flex items-center justify-center">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                </div>
                <span className="text-[13px] font-semibold text-white">Equity Curve</span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground bg-white/[0.04] rounded-lg px-2.5 py-1 border border-white/[0.06]">
                <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
                Account Balance
              </div>
            </div>
            <div className="h-[200px] px-1 pb-3">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={equity} margin={{ top: 8, right: 12, left: -8, bottom: 0 }}>
                  <defs>
                    <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={PURPLE} stopOpacity={0.35} />
                      <stop offset="60%" stopColor={PURPLE} stopOpacity={0.05} />
                      <stop offset="100%" stopColor={PURPLE} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="date" stroke="transparent" tick={{ fill: "hsl(220 10% 42%)", fontSize: 10 }} tickLine={false} axisLine={false}
                    tickFormatter={(v) => new Date(v).toLocaleDateString("en-US", { month: "short", day: "numeric" })} />
                  <YAxis stroke="transparent" tick={{ fill: "hsl(220 10% 42%)", fontSize: 10 }} tickLine={false} axisLine={false}
                    tickFormatter={(v) => `$${(v / 1000).toFixed(1)}k`} />
                  <Tooltip content={<CustomEquityTooltip />} />
                  <Area type="monotone" dataKey="equity" stroke={PURPLE} strokeWidth={2.5} fill="url(#equityGrad)" dot={false}
                    activeDot={{ r: 5, fill: PURPLE, stroke: "hsl(225 28% 9%)", strokeWidth: 2.5 }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>

        <motion.div variants={item}>
          <div className="glass-card h-full">
            <div className="p-5 pb-2 flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary/15 flex items-center justify-center">
                <BarChart2 className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="text-[13px] font-semibold text-white">Weekly PNL</span>
            </div>
            <div className="h-[200px] px-1 pb-3">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={weeklyLabels} margin={{ top: 8, right: 12, left: -24, bottom: 0 }}>
                  <XAxis dataKey="label" stroke="transparent" tick={{ fill: "hsl(220 10% 42%)", fontSize: 10 }} tickLine={false} axisLine={false} />
                  <Tooltip content={<CustomPnlTooltip />} cursor={{ fill: "rgba(255,255,255,0.025)" }} />
                  <Bar dataKey="pnl" radius={[5, 5, 2, 2]} maxBarSize={26}>
                    {weeklyLabels.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? GREEN : RED} fillOpacity={0.9} />
                    ))}
                  </Bar>
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── Win/Loss Pie + Calendar ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <motion.div variants={item}>
          <div className="glass-card h-full">
            <div className="p-5 pb-2 flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary/15 flex items-center justify-center">
                <Flame className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="text-[13px] font-semibold text-white">Win vs Loss</span>
            </div>
            <div className="h-[190px] px-1">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={winLossData} cx="50%" cy="48%" innerRadius={52} outerRadius={76} paddingAngle={4} dataKey="value" strokeWidth={0}>
                    {winLossData.map((entry, index) => (
                      <Cell key={`pie-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} itemStyle={{ color: "hsl(220 15% 88%)" }}
                    formatter={(value: number, name: string) => [`${value} trades`, name]} />
                  <Legend iconType="circle" iconSize={7}
                    formatter={(value) => <span style={{ fontSize: 11, color: "hsl(220 10% 55%)" }}>{value}</span>} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-around text-center mx-5 mb-5 border-t border-white/[0.06] pt-3">
              <div>
                <p className="text-base font-bold text-emerald-400">{stats.winCount}</p>
                <p className="text-[10px] text-muted-foreground font-medium">Wins</p>
              </div>
              <div className="w-px bg-white/[0.06]" />
              <div>
                <p className="text-base font-bold text-red-400">{stats.lossCount}</p>
                <p className="text-[10px] text-muted-foreground font-medium">Losses</p>
              </div>
              <div className="w-px bg-white/[0.06]" />
              <div>
                <p className="text-base font-bold text-foreground">{stats.breakevenCount}</p>
                <p className="text-[10px] text-muted-foreground font-medium">Even</p>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div variants={item} className="lg:col-span-2">
          <div className="glass-card h-full">
            <div className="p-5 pb-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-primary/15 flex items-center justify-center">
                  <Activity className="w-3.5 h-3.5 text-primary" />
                </div>
                <span className="text-[13px] font-semibold text-white">Trading Calendar</span>
              </div>
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-sm bg-emerald-400/60 inline-block" /> Profit
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-sm bg-red-400/60 inline-block" /> Loss
                </span>
              </div>
            </div>
            <div className="px-5 pb-5">
              {calData ? (
                <CalendarHeatmap data={calData} year={now.getFullYear()} month={now.getMonth() + 1} />
              ) : (
                <div className="h-[180px] shimmer-loading rounded-lg" />
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── Recent Trades ── */}
      <motion.div variants={item}>
        <div className="glass-card">
          <div className="px-5 pt-5 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-primary/15 flex items-center justify-center">
                <TrendingUp className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="text-[13px] font-semibold text-white">Recent Trades</span>
              <span className="text-[11px] text-muted-foreground bg-white/[0.04] rounded-full px-2 py-0.5 border border-white/[0.06]">
                Last {recentTrades.trades.length}
              </span>
            </div>
            <Link href="/trades">
              <span className="text-[11px] text-muted-foreground hover:text-primary transition-colors flex items-center gap-0.5 cursor-pointer">
                View all <ChevronRight className="w-3 h-3" />
              </span>
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left min-w-[560px]">
              <thead>
                <tr className="border-y border-white/[0.05] bg-white/[0.015]">
                  {["Symbol", "Broker", "Direction", "Entry", "Exit", "PNL", "RR"].map((h) => (
                    <th key={h} className={`px-4 py-2.5 text-[10px] font-semibold text-muted-foreground/70 uppercase tracking-widest ${["Entry","Exit","PNL","RR"].includes(h) ? "text-right" : ""}`}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentTrades.trades.map((trade, idx) => {
                  const broker = BROKER_MAP[trade.symbol] ?? "IC Markets";
                  const rr = trade.riskRewardRatio;
                  return (
                    <motion.tr
                      key={trade.id}
                      className="border-b border-white/[0.04] hover:bg-white/[0.025] transition-colors group cursor-pointer"
                      initial={{ opacity: 0, x: -6 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.025, duration: 0.28 }}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-1 h-5 rounded-full flex-shrink-0" style={{ backgroundColor: trade.outcome === "win" ? GREEN : trade.outcome === "loss" ? RED : MUTED_CLR }} />
                          <span className="font-bold text-[13px] text-white">{trade.symbol}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[12px] text-muted-foreground">{broker}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={`text-[10px] font-bold px-2 py-0.5 border-0 rounded-md ${
                          trade.side === "long" ? "bg-blue-500/10 text-blue-400" : "bg-orange-500/10 text-orange-400"
                        }`}>
                          {trade.side.toUpperCase()}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-[11px] text-muted-foreground tabular-nums">
                        {trade.entryPrice < 1 ? trade.entryPrice.toFixed(5) : trade.entryPrice.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-[11px] text-muted-foreground tabular-nums">
                        {trade.exitPrice < 1 ? trade.exitPrice.toFixed(5) : trade.exitPrice.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className={`px-4 py-3 text-right font-mono font-bold text-[13px] tabular-nums ${trade.pnl >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                        {trade.pnl >= 0 ? "+" : ""}{formatCurrency(trade.pnl)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {rr != null ? (
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${rr >= 2 ? "text-emerald-400 bg-emerald-400/10" : rr >= 1 ? "text-amber-400 bg-amber-400/10" : "text-red-400 bg-red-400/10"}`}>
                            {rr.toFixed(1)}R
                          </span>
                        ) : <span className="text-muted-foreground/50 text-sm">—</span>}
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
            {recentTrades.trades.length === 0 && (
              <div className="text-center py-12 text-muted-foreground text-sm">
                No trades yet — start logging to see analytics.
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
