import { useGetStatsSummary, useGetSymbolBreakdown } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { PieChart, Pie, Cell as PieCell } from "recharts";

export default function Reports() {
  const { data: stats } = useGetStatsSummary();
  const { data: symbolStats } = useGetSymbolBreakdown();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (!stats || !symbolStats) {
    return <div className="p-8 text-center text-muted-foreground animate-pulse">Loading reports...</div>;
  }

  const winLossData = [
    { name: 'Wins', value: stats.winCount, color: 'hsl(142 70% 48%)' },
    { name: 'Losses', value: stats.lossCount, color: 'hsl(0 72% 55%)' },
    { name: 'Breakeven', value: stats.breakevenCount, color: 'hsl(220 10% 55%)' },
  ];

  return (
    <motion.div 
      className="space-y-6 pb-12"
      variants={container}
      initial="hidden"
      animate="show"
    >
      <div>
        <h1 className="text-2xl font-bold tracking-tight mb-2">Performance Reports</h1>
        <p className="text-muted-foreground">Deep dive into your trading analytics.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div variants={item}>
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-base">Win/Loss Distribution</CardTitle>
            </CardHeader>
            <CardContent className="flex justify-center items-center h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={winLossData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {winLossData.map((entry, index) => (
                      <PieCell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item} className="md:col-span-2">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-base">Symbol Performance (PNL)</CardTitle>
            </CardHeader>
            <CardContent className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={symbolStats} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis 
                    dataKey="symbol" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    cursor={{ fill: 'hsl(var(--muted)/0.2)' }}
                    formatter={(value: number) => [formatCurrency(value), "PNL"]}
                  />
                  <Bar dataKey="pnl" radius={[4, 4, 4, 4]}>
                    {symbolStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? "hsl(142 70% 48%)" : "hsl(0 72% 55%)"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div variants={item}>
          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="text-sm font-medium text-muted-foreground mb-1">Average Win</div>
              <div className="text-2xl font-bold text-green-500">{formatCurrency(stats.averageWin)}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={item}>
          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="text-sm font-medium text-muted-foreground mb-1">Average Loss</div>
              <div className="text-2xl font-bold text-red-500">{formatCurrency(stats.averageLoss)}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={item}>
          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="text-sm font-medium text-muted-foreground mb-1">Largest Win</div>
              <div className="text-2xl font-bold text-green-500">{formatCurrency(stats.largestWin)}</div>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div variants={item}>
          <Card className="glass-card">
            <CardContent className="p-6">
              <div className="text-sm font-medium text-muted-foreground mb-1">Largest Loss</div>
              <div className="text-2xl font-bold text-red-500">{formatCurrency(stats.largestLoss)}</div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={item}>
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-base">Symbol Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase border-b border-white/5">
                  <tr>
                    <th className="px-4 py-3 font-medium">Symbol</th>
                    <th className="px-4 py-3 font-medium text-right">Trades</th>
                    <th className="px-4 py-3 font-medium text-right">Win Rate</th>
                    <th className="px-4 py-3 font-medium text-right">Net PNL</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {symbolStats.map((stat) => (
                    <tr key={stat.symbol} className="hover:bg-white/5 transition-colors">
                      <td className="px-4 py-3 font-medium text-white">{stat.symbol}</td>
                      <td className="px-4 py-3 text-right font-mono text-muted-foreground">{stat.trades}</td>
                      <td className="px-4 py-3 text-right font-mono text-white">{formatPercentage(stat.winRate)}</td>
                      <td className={`px-4 py-3 text-right font-mono font-medium ${stat.pnl >= 0 ? "text-green-500" : "text-red-500"}`}>
                        {formatCurrency(stat.pnl)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
