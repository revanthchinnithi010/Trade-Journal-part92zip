import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { motion } from "framer-motion";
import { User, CreditCard, Shield, Bell, Palette, Trash2, Zap, Check } from "lucide-react";

const container = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.07 } } };
const item = { hidden: { opacity: 0, y: 12 }, show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } } };

function SectionHeader({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="flex items-center gap-3 mb-1">
      <div className="w-8 h-8 rounded-xl bg-primary/15 border border-primary/20 flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div>
        <h3 className="text-[15px] font-semibold text-white leading-tight">{title}</h3>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

export default function Settings() {
  return (
    <motion.div className="space-y-6 max-w-3xl pb-12" variants={container} initial="hidden" animate="show">
      <motion.div variants={item}>
        <h1 className="text-2xl font-black tracking-tight text-white mb-1">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage your TradeVault account and preferences.</p>
      </motion.div>

      {/* Profile */}
      <motion.div variants={item}>
        <Card className="glass-card border-white/[0.07]">
          <CardHeader className="pb-4">
            <SectionHeader icon={User} title="Profile" description="Your personal information and display name" />
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center p-4 rounded-xl bg-white/[0.03] border border-white/[0.06]">
              <div className="w-16 h-16 rounded-2xl border-2 border-primary/25 bg-gradient-to-br from-primary/25 to-primary/5 flex items-center justify-center flex-shrink-0 shadow-lg shadow-primary/10">
                <span className="text-primary text-xl font-black">RC</span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-[15px] text-white">Revanth Chinnithi</h3>
                <p className="text-sm text-muted-foreground">revanth@tradervault.io</p>
                <p className="text-[11px] text-muted-foreground/60 mt-0.5">Member since Jan 2025</p>
              </div>
              <Button variant="outline" size="sm" className="rounded-xl border-white/[0.1] bg-white/[0.04] hover:bg-white/[0.08] text-sm shrink-0">
                Edit Profile
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Display Name</Label>
                <Input defaultValue="Revanth C." className="bg-white/[0.03] border-white/[0.08] rounded-xl h-10 focus:border-primary/50" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Email</Label>
                <Input defaultValue="revanth@tradervault.io" className="bg-white/[0.03] border-white/[0.08] rounded-xl h-10 focus:border-primary/50" />
              </div>
            </div>
            <div className="flex justify-end">
              <Button size="sm" className="rounded-xl h-9 px-5 bg-primary hover:bg-primary/90">Save Changes</Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Subscription */}
      <motion.div variants={item}>
        <Card className="glass-card border-white/[0.07]">
          <CardHeader className="pb-4">
            <SectionHeader icon={CreditCard} title="Account & Billing" description="Your subscription plan and usage" />
          </CardHeader>
          <CardContent>
            <div className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Zap className="w-5 h-5 text-primary" fill="currentColor" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <h4 className="font-bold text-white text-[15px]">Pro Plan</h4>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/25">Active</span>
                </div>
                <p className="text-sm text-muted-foreground">Unlimited trades · Advanced analytics · TradingView integration</p>
              </div>
              <Button variant="outline" size="sm" className="rounded-xl border-primary/30 bg-primary/10 hover:bg-primary/20 text-primary shrink-0">
                Manage
              </Button>
            </div>

            <div className="mt-4 space-y-2">
              {["Unlimited trade logs", "Advanced analytics & reports", "TradingView integration", "Setup & mistake tagging", "Export to CSV/PDF"].map((feature) => (
                <div key={feature} className="flex items-center gap-2.5 text-sm text-muted-foreground">
                  <div className="w-4 h-4 rounded-full bg-emerald-500/15 flex items-center justify-center flex-shrink-0">
                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                  </div>
                  {feature}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Risk Management */}
      <motion.div variants={item}>
        <Card className="glass-card border-white/[0.07]">
          <CardHeader className="pb-4">
            <SectionHeader icon={Shield} title="Risk Management" description="Default risk parameters for trade logging" />
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Account Size ($)</Label>
                <Input defaultValue="12453" type="number" className="bg-white/[0.03] border-white/[0.08] rounded-xl h-10 focus:border-primary/50" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Max Risk Per Trade (%)</Label>
                <Input defaultValue="1" type="number" step="0.1" className="bg-white/[0.03] border-white/[0.08] rounded-xl h-10 focus:border-primary/50" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Daily Loss Limit ($)</Label>
                <Input defaultValue="200" type="number" className="bg-white/[0.03] border-white/[0.08] rounded-xl h-10 focus:border-primary/50" />
              </div>
            </div>
            <div className="flex justify-end">
              <Button size="sm" className="rounded-xl h-9 px-5 bg-primary hover:bg-primary/90">Save</Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Notifications & Appearance */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <motion.div variants={item}>
          <Card className="glass-card border-white/[0.07] h-full">
            <CardHeader className="pb-4">
              <SectionHeader icon={Bell} title="Notifications" description="Alert preferences" />
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Daily PNL summary", sub: "End of day report", defaultChecked: true },
                { label: "Win streak alerts", sub: "Notify on 3+ wins", defaultChecked: true },
                { label: "Loss limit warnings", sub: "Alert when near limit", defaultChecked: false },
              ].map((n) => (
                <div key={n.label} className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-white">{n.label}</p>
                    <p className="text-[11px] text-muted-foreground">{n.sub}</p>
                  </div>
                  <Switch defaultChecked={n.defaultChecked} />
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="glass-card border-white/[0.07] h-full">
            <CardHeader className="pb-4">
              <SectionHeader icon={Palette} title="Appearance" description="Display preferences" />
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Dark theme", sub: "Always on", defaultChecked: true },
                { label: "Compact tables", sub: "Smaller row height", defaultChecked: false },
                { label: "Show broker column", sub: "In trades table", defaultChecked: true },
              ].map((n) => (
                <div key={n.label} className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-white">{n.label}</p>
                    <p className="text-[11px] text-muted-foreground">{n.sub}</p>
                  </div>
                  <Switch defaultChecked={n.defaultChecked} />
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Danger Zone */}
      <motion.div variants={item}>
        <Card className="glass-card border-red-500/[0.12]">
          <CardHeader className="pb-4">
            <SectionHeader icon={Trash2} title="Danger Zone" description="Destructive account actions" />
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-red-500/[0.05] border border-red-500/[0.12]">
              <div>
                <p className="text-sm font-semibold text-white">Delete all trade data</p>
                <p className="text-[12px] text-muted-foreground">Permanently remove all trades, notes, and analytics. This cannot be undone.</p>
              </div>
              <Button variant="destructive" size="sm" className="rounded-xl shrink-0 bg-red-500/15 text-red-400 border border-red-500/20 hover:bg-red-500/25 hover:text-red-300">
                Delete All Data
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
