export const BROKER_MAP: Record<string, string> = {
  NAS100: "IC Markets",
  US30: "IC Markets",
  US500: "IC Markets",
  XAUUSD: "Pepperstone",
  EURUSD: "Pepperstone",
  BTCUSD: "Deriv",
  ETHUSD: "Deriv",
  SOLUSD: "Deriv",
  DOGEUSD: "Deriv",
  PEPEUSD: "Deriv",
  "Crude Oil": "OANDA",
};

export const TV_LINKS: Record<string, string> = {
  NAS100: "https://www.tradingview.com/chart/?symbol=CAPITALCOM%3ANAS100",
  XAUUSD: "https://www.tradingview.com/chart/?symbol=OANDA%3AXAUUSD",
  BTCUSD: "https://www.tradingview.com/chart/?symbol=BINANCE%3ABTCUSD",
};

export const SETUP_TAG_OPTIONS: string[] = [
  "Breakout",
  "Trend",
  "HOD/LOD",
  "VWAP",
  "EMA Bounce",
  "Support/Resistance",
  "Gap Fill",
  "Momentum",
  "Reversal",
  "Scalp",
];

export const MISTAKE_TAG_OPTIONS: string[] = [
  "Revenge Trade",
  "FOMO Entry",
  "No Stop Loss",
  "Early Exit",
  "Overleverage",
  "Poor Entry",
  "Wrong Direction",
  "News Ignorance",
];

export const ASSET_CATEGORIES: Record<string, string[]> = {
  Indices: ["NAS100", "US30", "US500"],
  Forex: ["EURUSD"],
  Commodities: ["XAUUSD", "Crude Oil"],
  Crypto: ["BTCUSD", "ETHUSD", "SOLUSD", "DOGEUSD", "PEPEUSD"],
};

export const ALL_SYMBOLS = Object.values(ASSET_CATEGORIES).flat();
