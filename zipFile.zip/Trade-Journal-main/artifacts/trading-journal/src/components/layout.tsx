import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  LineChart,
  BarChart2,
  Calendar as CalendarIcon,
  BookOpen,
  Settings,
  Menu,
  X,
  Zap,
  Search,
  Bell,
  ChevronDown,
  TrendingUp,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/trades", label: "Trades", icon: LineChart },
  { href: "/reports", label: "Reports", icon: BarChart2 },
  { href: "/calendar", label: "Calendar", icon: CalendarIcon },
  { href: "/notebook", label: "Notebook", icon: BookOpen },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const currentPageLabel =
    NAV_ITEMS.find((item) => item.href === location)?.label || "TradeVault";

  return (
    <div className="flex h-[100dvh] w-full bg-background text-foreground overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 border-r border-white/[0.06] bg-sidebar transition-transform duration-300 ease-in-out md:static md:translate-x-0 flex flex-col",
          "bg-gradient-to-b from-[hsl(225,28%,7%)] to-[hsl(225,25%,6%)]",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex h-16 shrink-0 items-center px-5 border-b border-white/[0.06]">
          <div className="flex items-center gap-2.5 font-bold text-[17px] tracking-tight text-white">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center shadow-lg shadow-primary/20">
              <Zap className="w-4.5 h-4.5 text-primary" fill="currentColor" />
            </div>
            <span className="bg-gradient-to-r from-white to-white/70 bg-clip-text text-transparent">
              TradeVault
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden ml-auto w-8 h-8 text-muted-foreground hover:text-white"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          <p className="text-[10px] font-semibold text-muted-foreground/60 uppercase tracking-widest px-3 pt-2 pb-2">
            Navigation
          </p>
          {NAV_ITEMS.map((navItem) => {
            const isActive = location === navItem.href;
            return (
              <Link key={navItem.href} href={navItem.href} onClick={() => setSidebarOpen(false)}>
                <motion.div
                  whileHover={{ x: isActive ? 0 : 3 }}
                  transition={{ duration: 0.15 }}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer relative overflow-hidden group",
                    isActive
                      ? "bg-primary/15 text-white shadow-sm shadow-primary/10"
                      : "text-muted-foreground hover:bg-white/[0.05] hover:text-white/90"
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-primary rounded-r-full"
                    />
                  )}
                  <navItem.icon
                    className={cn(
                      "w-4 h-4 shrink-0 transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground group-hover:text-white/70"
                    )}
                  />
                  {navItem.label}
                  {isActive && (
                    <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent pointer-events-none" />
                  )}
                </motion.div>
              </Link>
            );
          })}
        </nav>

        {/* Account Summary */}
        <div className="p-3 border-t border-white/[0.06]">
          <div className="p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400/50" />
                <span className="text-xs text-muted-foreground">Account Balance</span>
              </div>
              <TrendingUp className="w-3 h-3 text-emerald-400" />
            </div>
            <p className="text-sm font-bold text-white tracking-tight">$12,453.20</p>
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/25">
                Pro Plan
              </span>
              <span className="text-[10px] text-emerald-400 font-medium">+$1,986 MTD</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        {/* Top Navbar */}
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-white/[0.06] bg-background/70 backdrop-blur-xl px-5 z-30 sticky top-0">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden shrink-0 -ml-1 w-8 h-8 text-muted-foreground hover:text-white"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-4.5 h-4.5" />
            </Button>
            <h1 className="text-[15px] font-semibold text-white/90 tracking-tight hidden sm:block">
              {currentPageLabel}
            </h1>
          </div>

          {/* Search */}
          <div className="flex-1 flex items-center justify-center px-8 max-w-sm mx-auto hidden md:flex">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/70" />
              <input
                type="text"
                placeholder="Search trades, symbols..."
                className="w-full h-8 pl-8.5 pr-4 rounded-lg bg-white/[0.04] border border-white/[0.07] text-xs focus:outline-none focus:ring-1 focus:ring-primary/60 focus:border-primary/40 transition-all text-white placeholder:text-muted-foreground/60"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Notifications */}
            <button className="relative w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-white hover:bg-white/[0.05] transition-all">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 flex h-2.5 w-2.5 items-center justify-center rounded-full bg-red-500 text-[8px] font-bold text-white border border-background">
                3
              </span>
            </button>
            <div className="w-px h-5 bg-white/[0.08] hidden sm:block" />
            {/* User */}
            <div className="flex items-center gap-2 cursor-pointer group select-none">
              <div className="w-7 h-7 rounded-lg border border-primary/25 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center flex-shrink-0 shadow-sm shadow-primary/10">
                <span className="text-primary text-[11px] font-bold">RC</span>
              </div>
              <span className="text-[13px] font-medium text-white/80 hidden sm:block group-hover:text-white transition-colors">
                Revanth C.
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-muted-foreground/60 hidden sm:block" />
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto">
          <div className="p-4 md:p-6 pb-8 mx-auto max-w-7xl min-h-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
