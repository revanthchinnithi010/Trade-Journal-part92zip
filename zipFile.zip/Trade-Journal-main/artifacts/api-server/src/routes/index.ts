import { Router, type IRouter } from "express";
import healthRouter from "./health";
import tradesRouter from "./trades";
import statsRouter from "./stats";
import notesRouter from "./notes";

const router: IRouter = Router();

router.use(healthRouter);
router.use(tradesRouter);
router.use(statsRouter);
router.use(notesRouter);

export default router;
