export default function GlassCard({ children, className = "" }) {
  return (
    <div className={`relative isolate overflow-hidden rounded-3xl bg-glass backdrop-blur-[20px] backdrop-saturate-[165%] border border-white/10 shadow-glass ${className}`}>
      <span
        className="absolute inset-0 rounded-[inherit] pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 120% 70% at 50% -20%, rgba(255,255,255,.14) 0%, rgba(255,255,255,0) 70%)",
          mixBlendMode: "screen",
          opacity: .7,
        }}
      />
      <span
        className="absolute inset-0 rounded-[inherit] pointer-events-none"
        style={{
          boxShadow: "inset 0 1px 0 rgba(255,255,255,.12), inset 0 0 0 1px rgba(255,255,255,.06), inset 0 -1px 0 rgba(255,255,255,.02)",
        }}
      />
      <div className="relative z-10 p-6">{children}</div>
    </div>
  );
}
